package dbms.DBMSFinalProject.helper;

public class BankSystemConstants {
    public static int success = 0;
    public static int failure = 1;
    public static int emailAlreadyPresent = 2;
    public static String adminUser = "A";
    public static String customer = "C";
    public static String secretKey = "bankSystem_DBMS_knights";
    public static String subscribe = "Y";
    public static String unsubscribe = "N";
}
