package dbms.DBMSFinalProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DbmsFinalProjectApplication {

    public static void main(String[] args) {
    	SpringApplication.run(DbmsFinalProjectApplication.class, args);
    }

}
