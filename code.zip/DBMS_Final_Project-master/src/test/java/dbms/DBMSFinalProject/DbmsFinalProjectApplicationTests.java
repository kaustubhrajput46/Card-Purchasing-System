package dbms.DBMSFinalProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbmsFinalProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
